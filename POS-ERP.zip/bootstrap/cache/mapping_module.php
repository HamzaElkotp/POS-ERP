<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Mapping\\Providers\\MappingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Mapping\\Providers\\MappingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);