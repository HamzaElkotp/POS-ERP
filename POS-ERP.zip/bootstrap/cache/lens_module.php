<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Lens\\Providers\\LensServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Lens\\Providers\\LensServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);