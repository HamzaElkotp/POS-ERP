<?php

return [
    'connector_module' => 'وحدة الموصل',
    'connector' => 'الموصل',
    'create_client' => 'إنشاء عميل',
    'client_secret' => 'سر العميل',
    'clients' => 'العملاء',
    'documentation' => 'الوثائق',
];
