<?php

return [
    'name' => 'Accounting',
    'module_version' => '0.6',
    'pid' => 16,
];
