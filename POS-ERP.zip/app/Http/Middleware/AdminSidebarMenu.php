<?php

namespace App\Http\Middleware;

use Menu;
use Closure;
use App\Business;
use App\Utils\ModuleUtil;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Request;

class AdminSidebarMenu
{


    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->ajax()) {
            return $next($request);
        }

        Menu::create('admin-sidebar-menu', function ($menu) {
            $business = Business::find(auth()->user()->business_id);
            $mod = $business->subscriptions;
            foreach ($mod as $item) {
                $package_modules = $item->package['custom_permissions'];

            }

            $enabled_modules1 = !empty(session('business.enabled_modules')) ? session('business.enabled_modules') : [];

            $enabled_modules = array_merge($enabled_modules1, array_keys($package_modules));
            // dd($enabled_modules);
            $common_settings = !empty(session('business.common_settings')) ? session('business.common_settings') : [];
            $pos_settings = !empty(session('business.pos_settings')) ? json_decode(session('business.pos_settings'), true) : [];

            $is_admin = auth()->user()->hasRole('Admin#' . session('business.id')) ? true : false;
            $is_admin1 = auth()->user()->hasRole('Admin') ? true : false;

            //superadmin
            if (auth()->user()->hasRole('Admin#1')) {
                $menu->dropdown(
                    __('Superadmin'),
                    function ($sub) {
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin'),
                                __('Dashboard'),
                                ['icon' => 'fas fa-chart-bar', 'active' => request()->segment(2) == 'superadmin']
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin/business'),
                                __('All Businesses'),
                                ['icon' => 'fas fa-building', 'active' => request()->segment(2) == 'business']
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin/superadmin-subscription'),
                                __('Subscription'),
                                ['icon' => 'fas fa-credit-card', 'active' => request()->segment(2) == 'superadmin-subscription']
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin/packages'),
                                __('Packages'),
                                ['icon' => 'fas fa-box', 'active' => request()->segment(2) == 'packages']
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin/settings'),
                                __('Settings'),
                                [
                                    'icon' => 'fas fa-cog',
                                    'active' => request()->is('superadmin/settings*')
                                ]
                            );
                        }

                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/superadmin/communicator'),
                                __('Communicator'),
                                ['icon' => 'fas fa-comments', 'active' => request()->segment(2) == 'communicator']
                            );
                        }
                    },
                    ['icon' => 'fas fa-user-shield']
                )->order(0);
            }

            //Home
            $menu->url(action([\App\Http\Controllers\HomeController::class, 'index']), __('home.home'), ['icon' => 'fa fas fa-tachometer-alt', 'active' => request()->segment(1) == 'home'])->order(5);

            //pos repair

            // $menu->url(url('/pos/create?sub_type=repair'), __('Repair'), ['icon' => 'fa fas fa-tools', 'active' => request()->segment(1) == 'repair'])->order(5);


            //Point's of sale
            if (auth()->user()->can('user.view') || auth()->user()->can('user.create') || auth()->user()->can('roles.view')) {
                $menu->dropdown(
                    __('Point of Sale'),
                    function ($sub) {
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellPosController::class, 'create']),
                                __("POS"),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'profit',
                                ]
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                '#',
                                __("Today's Profit"),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'profit',
                                    'title' => __('home.todays_profit'),
                                    'data-toggle' => 'tooltip',
                                    'data-placement' => 'bottom',
                                    'onclick' => "$('#view_todays_profit').click(); return true;"
                                ]
                            );
                        }
                    },
                    ['icon' => 'fas fa-money-bill-alt']
                )->order(10);
            }

            // tools
            if (auth()->user()->can('user.view') || auth()->user()->can('user.create') || auth()->user()->can('roles.view')) {
                $menu->dropdown(
                    __('Tools'),
                    function ($sub) {
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                url('/calendar'),
                                __('Calendar'),
                                ['icon' => 'far fa-calendar-alt', 'active' => request()->segment(1) == 'calendar']
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                '#',
                                __('Add To Do'),
                                [
                                    'icon' => 'fas fa-user',
                                    'class' => 'btn-modal',
                                    'data-container' => '#task_modal',
                                    'data-toggle' => 'modal',
                                    'data-target' => '#task_modal',
                                    'data-href' => action([\Modules\Essentials\Http\Controllers\ToDoController::class, 'create']),
                                ]
                            );
                        }
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                '#',
                                __('Clock In'),
                                [
                                    'icon' => 'fas fa-user',
                                    'class' => 'clock_in_btn',
                                    'data-container' => '#task_modal',
                                    'data-toggle' => 'modal',
                                    'data-target' => '#task_modal',
                                    'data-type' => 'clock_in',
                                    'data-toggle' => 'tooltip',
                                    'data-placement' => 'bottom',
                                ]
                            );
                        }
                    },
                    ['icon' => 'fa fa-calendar-alt']
                )->order(10);
            }

            //User management dropdown
            if (auth()->user()->can('user.view') || auth()->user()->can('user.create') || auth()->user()->can('roles.view')) {
                $menu->dropdown(
                    __('user.user_management'),
                    function ($sub) {
                        if (auth()->user()->can('user.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ManageUserController::class, 'index']),
                                __('user.users'),
                                ['icon' => 'fa fas fa-user', 'active' => request()->segment(1) == 'users']
                            );
                        }
                        if (auth()->user()->can('roles.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\RoleController::class, 'index']),
                                __('user.roles'),
                                ['icon' => 'fa fas fa-briefcase', 'active' => request()->segment(1) == 'roles']
                            );
                        }
                        if (auth()->user()->can('user.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\SalesCommissionAgentController::class, 'index']),
                                __('lang_v1.sales_commission_agents'),
                                ['icon' => 'fa fas fa-handshake', 'active' => request()->segment(1) == 'sales-commission-agents']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-users']
                )->order(10);
            }

            //Contacts dropdown
            if (auth()->user()->can('supplier.view') || auth()->user()->can('customer.view') || auth()->user()->can('supplier.view_own') || auth()->user()->can('customer.view_own')) {
                $menu->dropdown(
                    __('contact.contacts'),
                    function ($sub) {
                        if (auth()->user()->can('supplier.view') || auth()->user()->can('supplier.view_own')) {
                            $sub->url(
                                action([\App\Http\Controllers\ContactController::class, 'index'], ['type' => 'supplier']),
                                __('report.supplier'),
                                ['icon' => 'fa fas fa-star', 'active' => request()->input('type') == 'supplier']
                            );
                        }
                        if (auth()->user()->can('customer.view') || auth()->user()->can('customer.view_own')) {
                            $sub->url(
                                action([\App\Http\Controllers\ContactController::class, 'index'], ['type' => 'customer']),
                                __('report.customer'),
                                ['icon' => 'fa fas fa-star', 'active' => request()->input('type') == 'customer']
                            );
                            $sub->url(
                                action([\App\Http\Controllers\CustomerGroupController::class, 'index']),
                                __('lang_v1.customer_groups'),
                                ['icon' => 'fa fas fa-users', 'active' => request()->segment(1) == 'customer-group']
                            );
                        }
                        if (auth()->user()->can('supplier.create') || auth()->user()->can('customer.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\ContactController::class, 'getImportContacts']),
                                __('lang_v1.import_contacts'),
                                ['icon' => 'fa fas fa-download', 'active' => request()->segment(1) == 'contacts' && request()->segment(2) == 'import']
                            );
                        }

                        if (!empty(env('GOOGLE_MAP_API_KEY'))) {
                            $sub->url(
                                action([\App\Http\Controllers\ContactController::class, 'contactMap']),
                                __('lang_v1.map'),
                                ['icon' => 'fa fas fa-map-marker-alt', 'active' => request()->segment(1) == 'contacts' && request()->segment(2) == 'map']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-address-book', 'id' => 'tour_step4']
                )->order(15);
            }

            //Products dropdown
            if (
                auth()->user()->can('product.view') || auth()->user()->can('product.create') ||
                auth()->user()->can('brand.view') || auth()->user()->can('unit.view') ||
                auth()->user()->can('category.view') || auth()->user()->can('brand.create') ||
                auth()->user()->can('unit.create') || auth()->user()->can('category.create')
            ) {

                $menu->dropdown(

                    __('sale.products'),
                    function ($sub) {
                        if (auth()->user()->can('product.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ProductController::class, 'index']),
                                __('lang_v1.list_products'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'products' && request()->segment(2) == '']
                            );
                        }


                        if (auth()->user()->can('product.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\ProductController::class, 'create']),
                                __('product.add_product'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'products' && request()->segment(2) == 'create']
                            );
                        }
                        if (auth()->user()->can('product.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellingPriceGroupController::class, 'updateProductPrice']),
                                __('lang_v1.update_product_price'),
                                ['icon' => 'fa fas fa-circle', 'active' => request()->segment(1) == 'update-product-price']
                            );
                        }
                        if (auth()->user()->can('product.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\LabelsController::class, 'show']),
                                __('barcode.print_labels'),
                                ['icon' => 'fa fas fa-barcode', 'active' => request()->segment(1) == 'labels' && request()->segment(2) == 'show']
                            );
                        }
                        if (auth()->user()->can('product.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\VariationTemplateController::class, 'index']),
                                __('product.variations'),
                                ['icon' => 'fa fas fa-circle', 'active' => request()->segment(1) == 'variation-templates']
                            );
                            $sub->url(
                                action([\App\Http\Controllers\ImportProductsController::class, 'index']),
                                __('product.import_products'),
                                ['icon' => 'fa fas fa-download', 'active' => request()->segment(1) == 'import-products']
                            );
                        }
                        if (auth()->user()->can('product.opening_stock')) {
                            $sub->url(
                                action([\App\Http\Controllers\ImportOpeningStockController::class, 'index']),
                                __('lang_v1.import_opening_stock'),
                                ['icon' => 'fa fas fa-download', 'active' => request()->segment(1) == 'import-opening-stock']
                            );
                        }
                        if (auth()->user()->can('product.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellingPriceGroupController::class, 'index']),
                                __('lang_v1.selling_price_group'),
                                ['icon' => 'fa fas fa-circle', 'active' => request()->segment(1) == 'selling-price-group']
                            );
                        }
                        if (auth()->user()->can('unit.view') || auth()->user()->can('unit.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\UnitController::class, 'index']),
                                __('unit.units'),
                                ['icon' => 'fa fas fa-balance-scale', 'active' => request()->segment(1) == 'units']
                            );
                        }
                        if (auth()->user()->can('category.view') || auth()->user()->can('category.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\TaxonomyController::class, 'index']) . '?type=product',
                                __('category.categories'),
                                ['icon' => 'fa fas fa-tags', 'active' => request()->segment(1) == 'taxonomies' && request()->get('type') == 'product']
                            );
                        }
                        if (auth()->user()->can('brand.view') || auth()->user()->can('brand.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\BrandController::class, 'index']),
                                __('brand.brands'),
                                ['icon' => 'fa fas fa-gem', 'active' => request()->segment(1) == 'brands']
                            );
                        }

                        $sub->url(
                            action([\App\Http\Controllers\WarrantyController::class, 'index']),
                            __('lang_v1.warranties'),
                            ['icon' => 'fa fas fa-shield-alt', 'active' => request()->segment(1) == 'warranties']
                        );
                        $business = Business::find(auth()->user()->business_id);
                        $mod = $business->subscriptions;
                        foreach ($mod as $item) {
                            $package_modules = $item->package['custom_permissions'];

                        }
                        // dd( $package_modules);
                        $enabled_modules1 = !empty(session('business.enabled_modules')) ? session('business.enabled_modules') : [];

                        $enabled_modules = array_merge($enabled_modules1, array_keys($package_modules));

                        // if (in_array('lens_module', $enabled_modules)) {
                        //     $sub->url(
                        //         action([\Modules\Lens\Http\Controllers\LensController::class, 'index']),
                        //         __('lens::lang.lens'),
                        //         ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'lens']
                        //     );
                        // }
                    },

                    ['icon' => 'fa fas fa-cubes', 'id' => 'tour_step5']
                )->order(20);
            }


            // manufaction 
            if (auth()->user()->can('manufacturing.access_recipe') || auth()->user()->can('manufacturing.access_production')) {
                $menu->dropdown(
                    __('Manufaction'),
                    function ($sub) {
                        if (auth()->user()->can('manufacturing.access_recipe')) {
                            $sub->url(
                                url('/manufacturing/recipe'),
                                __('Recipe'),
                                ['icon' => 'fas fa-book', 'active' => request()->segment(2) == 'recipe']
                            );
                        }
                        if (auth()->user()->can('manufacturing.access_production')) {
                            $sub->url(
                                url('/manufacturing/production'),
                                __('Production'),
                                ['icon' => 'fas fa-industry', 'active' => request()->segment(2) == 'production']
                            );
                            $sub->url(
                                url('/manufacturing/settings'),
                                __('Settings'),
                                [
                                    'icon' => 'fas fa-cog',
                                    'active' => Request::is('manufacturing/settings*')
                                ]
                            );
                            $sub->url(
                                url('/manufacturing/report'),
                                __('Manufacturing Report'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(2) == 'report']
                            );
                        }
                    },
                    ['icon' => 'fas fa-industry']
                )->order(20);
            }
            //Repait
            if (
                in_array('repair_module', $enabled_modules) && (
                    auth()->user()->can('job_sheet.create') ||
                    auth()->user()->can('job_sheet.view_assigned') ||
                    auth()->user()->can('job_sheet.view_all') ||
                    auth()->user()->can('repair.view') ||
                    auth()->user()->can('repair.view_own') ||
                    auth()->user()->can('repair.create') ||
                    auth()->user()->can('brand.view') ||
                    auth()->user()->can('brand.create') ||
                    auth()->user()->can('edit_repair_settings'))
            ) {
                $menu->dropdown(
                    __('Repair'),
                    function ($sub) {
                        if (auth()->user()->can('job_sheet.create') || auth()->user()->can('job_sheet.view_assigned') || auth()->user()->can('job_sheet.view_all')) {
                            $sub->url(
                                action([\Modules\Repair\Http\Controllers\JobSheetController::class, 'index']),
                                __('repair::lang.job_sheets'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'repair' && request()->segment(2) == 'job-sheet',
                                ]
                            );
                        }
                        if (auth()->user()->can('job_sheet.create')) {
                            $sub->url(
                                action([\Modules\Repair\Http\Controllers\JobSheetController::class, 'create']),
                                __('repair::lang.add_job_sheet'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'repair' && request()->segment(2) == 'job-sheet' && request()->segment(3) == 'create',
                                ]
                            );
                        }
                        if (auth()->user()->can('repair.view') || auth()->user()->can('repair.view_own')) {
                            $sub->url(
                                action([\Modules\Repair\Http\Controllers\RepairController::class, 'index']),
                                __('repair::lang.list_invoices'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'repair' && request()->segment(2) == 'repair',
                                ]
                            );
                        }
                        if (auth()->user()->can('repair.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellPosController::class, 'create']) . '?sub_type=repair',
                                __('repair::lang.add_invoice'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(2) == 'repair' && request()->segment(3) == 'create',
                                ]
                            );
                        }
                        if (auth()->user()->can('brand.view') || auth()->user()->can('brand.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\BrandController::class, 'index']),
                                __('brand.brands'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(1) == 'brands',
                                ]
                            );
                        }
                        if (auth()->user()->can('edit_repair_settings')) {
                            $sub->url(
                                action([\Modules\Repair\Http\Controllers\RepairSettingsController::class, 'index']),
                                __('messages.settings'),
                                [
                                    'icon' => 'fas fa-money-bill-alt',
                                    'active' => request()->segment(2) == 'repair-settings',
                                ]
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-tools']
                )->order(20);
            }



            //Purchase dropdown
            if (in_array('purchases', $enabled_modules) && (auth()->user()->can('purchase.view') || auth()->user()->can('purchase.create') || auth()->user()->can('purchase.update'))) {
                $menu->dropdown(
                    __('purchase.purchases'),
                    function ($sub) use ($common_settings) {
                        if (!empty($common_settings['enable_purchase_requisition']) && (auth()->user()->can('purchase_requisition.view_all') || auth()->user()->can('purchase_requisition.view_own'))) {
                            $sub->url(
                                action([\App\Http\Controllers\PurchaseRequisitionController::class, 'index']),
                                __('lang_v1.purchase_requisition'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'purchase-requisition']
                            );
                        }

                        if (!empty($common_settings['enable_purchase_order']) && (auth()->user()->can('purchase_order.view_all') || auth()->user()->can('purchase_order.view_own'))) {
                            $sub->url(
                                action([\App\Http\Controllers\PurchaseOrderController::class, 'index']),
                                __('lang_v1.purchase_order'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'purchase-order']
                            );
                        }
                        if (auth()->user()->can('purchase.view') || auth()->user()->can('view_own_purchase')) {
                            $sub->url(
                                action([\App\Http\Controllers\PurchaseController::class, 'index']),
                                __('purchase.list_purchase'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'purchases' && request()->segment(2) == null]
                            );
                        }
                        if (auth()->user()->can('purchase.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\PurchaseController::class, 'create']),
                                __('purchase.add_purchase'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'purchases' && request()->segment(2) == 'create']
                            );
                        }
                        if (auth()->user()->can('purchase.update')) {
                            $sub->url(
                                action([\App\Http\Controllers\PurchaseReturnController::class, 'index']),
                                __('lang_v1.list_purchase_return'),
                                ['icon' => 'fa fas fa-undo', 'active' => request()->segment(1) == 'purchase-return']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-arrow-circle-down', 'id' => 'tour_step6']
                )->order(25);
            }
            //Sell dropdown
            if ($is_admin || auth()->user()->hasAnyPermission(['sell.view', 'sell.create', 'direct_sell.access', 'view_own_sell_only', 'view_commission_agent_sell', 'access_shipping', 'access_own_shipping', 'access_commission_agent_shipping', 'access_sell_return', 'direct_sell.view', 'direct_sell.update', 'access_own_sell_return'])) {
                $menu->dropdown(
                    __('sale.sale'),
                    function ($sub) use ($enabled_modules, $is_admin, $pos_settings) {
                        if (!empty($pos_settings['enable_sales_order']) && ($is_admin || auth()->user()->hasAnyPermission(['so.view_own', 'so.view_all', 'so.create']))) {
                            $sub->url(
                                action([\App\Http\Controllers\SalesOrderController::class, 'index']),
                                __('lang_v1.sales_order'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'sales-order']
                            );
                        }

                        if ($is_admin || auth()->user()->hasAnyPermission(['sell.view', 'sell.create', 'direct_sell.access', 'direct_sell.view', 'view_own_sell_only', 'view_commission_agent_sell', 'access_shipping', 'access_own_shipping', 'access_commission_agent_shipping'])) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'index']),
                                __('lang_v1.all_sales'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'sells' && request()->segment(2) == null]
                            );
                        }
                        if (in_array('add_sale', $enabled_modules) && auth()->user()->can('direct_sell.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'create']),
                                __('sale.add_sale'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'sells' && request()->segment(2) == 'create' && empty(request()->get('status'))]
                            );
                        }
                        if (auth()->user()->can('sell.create')) {
                            if (in_array('pos_sale', $enabled_modules)) {
                                if (auth()->user()->can('sell.view')) {
                                    $sub->url(
                                        action([\App\Http\Controllers\SellPosController::class, 'index']),
                                        __('sale.list_pos'),
                                        ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'pos' && request()->segment(2) == null]
                                    );
                                }

                                $sub->url(
                                    action([\App\Http\Controllers\SellPosController::class, 'create']),
                                    __('sale.pos_sale'),
                                    ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'pos' && request()->segment(2) == 'create']
                                );
                            }
                        }

                        if (in_array('add_sale', $enabled_modules) && auth()->user()->can('direct_sell.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'create'], ['status' => 'draft']),
                                __('lang_v1.add_draft'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->get('status') == 'draft']
                            );
                        }
                        if (in_array('add_sale', $enabled_modules) && ($is_admin || auth()->user()->hasAnyPermission(['draft.view_all', 'draft.view_own']))) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'getDrafts']),
                                __('lang_v1.list_drafts'),
                                ['icon' => 'fa fas fa-pen-square', 'active' => request()->segment(1) == 'sells' && request()->segment(2) == 'drafts']
                            );
                        }
                        if (in_array('add_sale', $enabled_modules) && auth()->user()->can('direct_sell.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'create'], ['status' => 'quotation']),
                                __('lang_v1.add_quotation'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->get('status') == 'quotation']
                            );
                        }
                        if (in_array('add_sale', $enabled_modules) && ($is_admin || auth()->user()->hasAnyPermission(['quotation.view_all', 'quotation.view_own']))) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'getQuotations']),
                                __('lang_v1.list_quotations'),
                                ['icon' => 'fa fas fa-pen-square', 'active' => request()->segment(1) == 'sells' && request()->segment(2) == 'quotations']
                            );
                        }

                        if (auth()->user()->can('access_sell_return') || auth()->user()->can('access_own_sell_return')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellReturnController::class, 'index']),
                                __('lang_v1.list_sell_return'),
                                ['icon' => 'fa fas fa-undo', 'active' => request()->segment(1) == 'sell-return' && request()->segment(2) == null]
                            );
                        }

                        if ($is_admin || auth()->user()->hasAnyPermission(['access_shipping', 'access_own_shipping', 'access_commission_agent_shipping'])) {
                            $sub->url(
                                action([\App\Http\Controllers\SellController::class, 'shipments']),
                                __('lang_v1.shipments'),
                                ['icon' => 'fa fas fa-truck', 'active' => request()->segment(1) == 'shipments']
                            );
                        }

                        if (auth()->user()->can('discount.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\DiscountController::class, 'index']),
                                __('lang_v1.discounts'),
                                ['icon' => 'fa fas fa-percent', 'active' => request()->segment(1) == 'discount']
                            );
                        }
                        if (in_array('subscription', $enabled_modules) && auth()->user()->can('direct_sell.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\SellPosController::class, 'listSubscriptions']),
                                __('lang_v1.subscriptions'),
                                ['icon' => 'fa fas fa-recycle', 'active' => request()->segment(1) == 'subscriptions']
                            );
                        }

                        if (auth()->user()->can('sell.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\ImportSalesController::class, 'index']),
                                __('lang_v1.import_sales'),
                                ['icon' => 'fa fas fa-file-import', 'active' => request()->segment(1) == 'import-sales']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-arrow-circle-up', 'id' => 'tour_step7']
                )->order(30);
            }

            //Stock transfer dropdown
            if (in_array('stock_transfers', $enabled_modules) && (auth()->user()->can('purchase.view') || auth()->user()->can('purchase.create'))) {
                $menu->dropdown(
                    __('lang_v1.stock_transfers'),
                    function ($sub) {
                        if (auth()->user()->can('purchase.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\StockTransferController::class, 'index']),
                                __('lang_v1.list_stock_transfers'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'stock-transfers' && request()->segment(2) == null]
                            );
                        }
                        if (auth()->user()->can('purchase.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\StockTransferController::class, 'create']),
                                __('lang_v1.add_stock_transfer'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'stock-transfers' && request()->segment(2) == 'create']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-truck']
                )->order(35);
            }

            //stock adjustment dropdown
            if (in_array('stock_adjustment', $enabled_modules) && (auth()->user()->can('purchase.view') || auth()->user()->can('purchase.create'))) {
                $menu->dropdown(
                    __('stock_adjustment.stock_adjustment'),
                    function ($sub) {
                        if (auth()->user()->can('purchase.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\StockAdjustmentController::class, 'index']),
                                __('stock_adjustment.list'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'stock-adjustments' && request()->segment(2) == null]
                            );
                        }
                        if (auth()->user()->can('purchase.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\StockAdjustmentController::class, 'create']),
                                __('stock_adjustment.add'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'stock-adjustments' && request()->segment(2) == 'create']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-database']
                )->order(40);
            }

            //Expense dropdown
            if (in_array('expenses', $enabled_modules) && (auth()->user()->can('all_expense.access') || auth()->user()->can('view_own_expense'))) {
                $menu->dropdown(
                    __('expense.expenses'),
                    function ($sub) {
                        $sub->url(
                            action([\App\Http\Controllers\ExpenseController::class, 'index']),
                            __('lang_v1.list_expenses'),
                            ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'expenses' && request()->segment(2) == null]
                        );

                        if (auth()->user()->can('expense.add')) {
                            $sub->url(
                                action([\App\Http\Controllers\ExpenseController::class, 'create']),
                                __('expense.add_expense'),
                                ['icon' => 'fa fas fa-plus-circle', 'active' => request()->segment(1) == 'expenses' && request()->segment(2) == 'create']
                            );
                        }

                        if (auth()->user()->can('expense.add') || auth()->user()->can('expense.edit')) {
                            $sub->url(
                                action([\App\Http\Controllers\ExpenseCategoryController::class, 'index']),
                                __('expense.expense_categories'),
                                ['icon' => 'fa fas fa-circle', 'active' => request()->segment(1) == 'expense-categories']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-minus-circle']
                )->order(45);
            }

            // accounting 000000

            if (
                in_array('accounting_module', $enabled_modules) && (
                    auth()->user()->can('accounting.manage_accounts') ||
                    auth()->user()->can('accounting.view_journal') ||
                    auth()->user()->can('accounting.view_transfer') ||
                    auth()->user()->can('accounting.manage_budget') ||
                    auth()->user()->can('accounting.view_reports'))
            ) {
                $menu->dropdown(
                    __('Accounting'),
                    function ($sub) {

                        if (auth()->user()->can('accounting.manage_accounts')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\CoaController::class, 'index']),
                                __('accounting::lang.chart_of_accounts'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'chart-of-accounts']
                            );
                        }
                        if (auth()->user()->can('accounting.view_journal')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\JournalEntryController::class, 'index']),
                                __('accounting::lang.journal_entry'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'journal-entry']
                            );
                        }
                        // if (auth()->user()->can('accounting.view_journal')) {
                        //     $sub->url(
                        //         action([\Modules\Accounting\Http\Controllers\ReportController::class, 'get_acc_trans']),
                        //         __('accounting::lang.get_acc_trans'),
                        //         ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'get_acc_trans']
                        //     );
                        // }
                        if (auth()->user()->can('accounting.view_transfer')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\TransferController::class, 'index']),
                                __('accounting::lang.transfer'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'transfer']
                            );
                        }
                        if (auth()->user()->can('accounting.view_transfer')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\TransactionController::class, 'index']),
                                __('accounting::lang.transactions'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'transactions']
                            );
                        }
                        if (auth()->user()->can('accounting.manage_budget')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\BudgetController::class, 'index']),
                                __('accounting::lang.budget'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'budget']
                            );
                        }
                        if (auth()->user()->can('accounting.view_reports')) {
                            $sub->url(
                                action([\Modules\Accounting\Http\Controllers\ReportController::class, 'index']),
                                __('accounting::lang.reports'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'reports']
                            );
                        }
                        // if (auth()->user()->can('superadmin')) {
                        $sub->url(
                            action([\Modules\Accounting\Http\Controllers\SettingsController::class, 'index']),
                            __('messages.settings'),
                            ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'settings']
                        );
                        // }
                        // if (auth()->user()->can('superadmin')) {
                        $sub->url(
                            action([\Modules\Accounting\Http\Controllers\MappingController::class, 'edit']),
                            __('accounting::lang.mapping'),
                            ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'accounting' && request()->segment(2) == 'mapping']
                        );
                        // }
                    },
                    ['icon' => 'fas fa-industry']
                )->order(45);
            }

            // Ai
            if (in_array('aiassistance_module', $enabled_modules) && (auth()->user()->can('aiassistance.access_aiassistance_module'))) {
                $menu->dropdown(
                    __('AI Aiassistance'),
                    function ($sub) {
                        if (auth()->user()->can('aiassistance.access_aiassistance_module')) {
                            $sub->url(
                                action([\Modules\AiAssistance\Http\Controllers\AiAssistanceController::class, 'index']),
                                __('aiassistance::lang.aiassistance'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'aiassistance' && request()->segment(2) == 'dashboard']
                            );
                        }
                        if (auth()->user()->can('aiassistance.access_aiassistance_module')) {
                            $sub->url(
                                action([\Modules\AiAssistance\Http\Controllers\AiAssistanceController::class, 'history']),
                                __('aiassistance::lang.history'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'aiassistance' && request()->segment(2) == 'history']
                            );
                        }
                    },
                    ['icon' => 'fas fa-robot']
                )->order(45);
            }
            //Accounts dropdown
            // if (auth()->user()->can('account.access') && in_array('account', $enabled_modules)) {
            //     $menu->dropdown(
            //         __('lang_v1.payment_accounts'),
            //         function ($sub) {
            //             $sub->url(
            //                 action([\App\Http\Controllers\AccountController::class, 'index']),
            //                 __('account.list_accounts'),
            //                 ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'account' && request()->segment(2) == 'account']
            //             );
            //             $sub->url(
            //                 action([\App\Http\Controllers\AccountReportsController::class, 'balanceSheet']),
            //                 __('account.balance_sheet'),
            //                 ['icon' => 'fa fas fa-book', 'active' => request()->segment(1) == 'account' && request()->segment(2) == 'balance-sheet']
            //             );
            //             $sub->url(
            //                 action([\App\Http\Controllers\AccountReportsController::class, 'trialBalance']),
            //                 __('account.trial_balance'),
            //                 ['icon' => 'fa fas fa-balance-scale', 'active' => request()->segment(1) == 'account' && request()->segment(2) == 'trial-balance']
            //             );
            //             $sub->url(
            //                 action([\App\Http\Controllers\AccountController::class, 'cashFlow']),
            //                 __('lang_v1.cash_flow'),
            //                 ['icon' => 'fa fas fa-exchange-alt', 'active' => request()->segment(1) == 'account' && request()->segment(2) == 'cash-flow']
            //             );
            //             $sub->url(
            //                 action([\App\Http\Controllers\AccountReportsController::class, 'paymentAccountReport']),
            //                 __('account.payment_account_report'),
            //                 ['icon' => 'fa fas fa-file-alt', 'active' => request()->segment(1) == 'account' && request()->segment(2) == 'payment-account-report']
            //             );
            //         },
            //         ['icon' => 'fa fas fa-money-check-alt']
            //     )->order(50);
            // }

            //Reports dropdown
            if (
                auth()->user()->can('purchase_n_sell_report.view') || auth()->user()->can('contacts_report.view')
                || auth()->user()->can('stock_report.view') || auth()->user()->can('tax_report.view')
                || auth()->user()->can('trending_product_report.view') || auth()->user()->can('sales_representative.view') || auth()->user()->can('register_report.view')
                || auth()->user()->can('expense_report.view')
            ) {
                $menu->dropdown(
                    __('report.reports'),
                    function ($sub) use ($enabled_modules, $is_admin) {
                        if (auth()->user()->can('profit_loss_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getProfitLoss']),
                                __('report.profit_loss'),
                                ['icon' => 'fa fas fa-file-invoice-dollar', 'active' => request()->segment(2) == 'profit-loss']
                            );
                        }
                        if (config('constants.show_report_606') == true) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'purchaseReport']),
                                'Report 606 (' . __('lang_v1.purchase') . ')',
                                ['icon' => 'fa fas fa-arrow-circle-down', 'active' => request()->segment(2) == 'purchase-report']
                            );
                        }
                        if (config('constants.show_report_607') == true) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'saleReport']),
                                'Report 607 (' . __('business.sale') . ')',
                                ['icon' => 'fa fas fa-arrow-circle-up', 'active' => request()->segment(2) == 'sale-report']
                            );
                        }
                        if ((in_array('purchases', $enabled_modules) || in_array('add_sale', $enabled_modules) || in_array('pos_sale', $enabled_modules)) && auth()->user()->can('purchase_n_sell_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getPurchaseSell']),
                                __('report.purchase_sell_report'),
                                ['icon' => 'fa fas fa-exchange-alt', 'active' => request()->segment(2) == 'purchase-sell']
                            );
                        }

                        if (auth()->user()->can('tax_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getTaxReport']),
                                __('report.tax_report'),
                                ['icon' => 'fa fas fa-percent', 'active' => request()->segment(2) == 'tax-report']
                            );
                        }
                        if (auth()->user()->can('contacts_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getCustomerSuppliers']),
                                __('report.contacts'),
                                ['icon' => 'fa fas fa-address-book', 'active' => request()->segment(2) == 'customer-supplier']
                            );
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getCustomerGroup']),
                                __('lang_v1.customer_groups_report'),
                                ['icon' => 'fa fas fa-users', 'active' => request()->segment(2) == 'customer-group']
                            );
                        }
                        if (auth()->user()->can('stock_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getStockReport']),
                                __('report.stock_report'),
                                ['icon' => 'fa fas fa-hourglass-half', 'active' => request()->segment(2) == 'stock-report']
                            );
                            if (session('business.enable_product_expiry') == 1) {
                                $sub->url(
                                    action([\App\Http\Controllers\ReportController::class, 'getStockExpiryReport']),
                                    __('report.stock_expiry_report'),
                                    ['icon' => 'fa fas fa-calendar-times', 'active' => request()->segment(2) == 'stock-expiry']
                                );
                            }
                            if (session('business.enable_lot_number') == 1) {
                                $sub->url(
                                    action([\App\Http\Controllers\ReportController::class, 'getLotReport']),
                                    __('lang_v1.lot_report'),
                                    ['icon' => 'fa fas fa-hourglass-half', 'active' => request()->segment(2) == 'lot-report']
                                );
                            }

                            if (in_array('stock_adjustment', $enabled_modules)) {
                                $sub->url(
                                    action([\App\Http\Controllers\ReportController::class, 'getStockAdjustmentReport']),
                                    __('report.stock_adjustment_report'),
                                    ['icon' => 'fa fas fa-sliders-h', 'active' => request()->segment(2) == 'stock-adjustment-report']
                                );
                            }
                        }

                        if (auth()->user()->can('trending_product_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getTrendingProducts']),
                                __('report.trending_products'),
                                ['icon' => 'fa fas fa-chart-line', 'active' => request()->segment(2) == 'trending-products']
                            );
                        }

                        if (auth()->user()->can('purchase_n_sell_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'itemsReport']),
                                __('lang_v1.items_report'),
                                ['icon' => 'fa fas fa-tasks', 'active' => request()->segment(2) == 'items-report']
                            );

                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getproductPurchaseReport']),
                                __('lang_v1.product_purchase_report'),
                                ['icon' => 'fa fas fa-arrow-circle-down', 'active' => request()->segment(2) == 'product-purchase-report']
                            );

                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getproductSellReport']),
                                __('lang_v1.product_sell_report'),
                                ['icon' => 'fa fas fa-arrow-circle-up', 'active' => request()->segment(2) == 'product-sell-report']
                            );

                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'purchasePaymentReport']),
                                __('lang_v1.purchase_payment_report'),
                                ['icon' => 'fa fas fa-search-dollar', 'active' => request()->segment(2) == 'purchase-payment-report']
                            );

                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'sellPaymentReport']),
                                __('lang_v1.sell_payment_report'),
                                ['icon' => 'fa fas fa-search-dollar', 'active' => request()->segment(2) == 'sell-payment-report']
                            );
                        }
                        if (in_array('expenses', $enabled_modules) && auth()->user()->can('expense_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getExpenseReport']),
                                __('report.expense_report'),
                                ['icon' => 'fa fas fa-search-minus', 'active' => request()->segment(2) == 'expense-report']
                            );
                        }
                        if (auth()->user()->can('register_report.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getRegisterReport']),
                                __('report.register_report'),
                                ['icon' => 'fa fas fa-briefcase', 'active' => request()->segment(2) == 'register-report']
                            );
                        }
                        if (auth()->user()->can('sales_representative.view')) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getSalesRepresentativeReport']),
                                __('report.sales_representative'),
                                ['icon' => 'fa fas fa-user', 'active' => request()->segment(2) == 'sales-representative-report']
                            );
                        }
                        if (auth()->user()->can('purchase_n_sell_report.view') && in_array('tables', $enabled_modules)) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getTableReport']),
                                __('restaurant.table_report'),
                                ['icon' => 'fa fas fa-table', 'active' => request()->segment(2) == 'table-report']
                            );
                        }

                        if (auth()->user()->can('tax_report.view') && !empty(config('constants.enable_gst_report_india'))) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'gstSalesReport']),
                                __('lang_v1.gst_sales_report'),
                                ['icon' => 'fa fas fa-percent', 'active' => request()->segment(2) == 'gst-sales-report']
                            );

                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'gstPurchaseReport']),
                                __('lang_v1.gst_purchase_report'),
                                ['icon' => 'fa fas fa-percent', 'active' => request()->segment(2) == 'gst-purchase-report']
                            );
                        }

                        if (auth()->user()->can('sales_representative.view') && in_array('service_staff', $enabled_modules)) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'getServiceStaffReport']),
                                __('restaurant.service_staff_report'),
                                ['icon' => 'fa fas fa-user-secret', 'active' => request()->segment(2) == 'service-staff-report']
                            );
                        }

                        if ($is_admin) {
                            $sub->url(
                                action([\App\Http\Controllers\ReportController::class, 'activityLog']),
                                __('lang_v1.activity_log'),
                                ['icon' => 'fa fas fa-user-secret', 'active' => request()->segment(2) == 'activity-log']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-chart-bar', 'id' => 'tour_step8']
                )->order(55);
            }

            //Backup menu
            if (auth()->user()->can('backup')) {
                $menu->url(action([\App\Http\Controllers\BackUpController::class, 'index']), __('lang_v1.backup'), ['icon' => 'fa fas fa-hdd', 'active' => request()->segment(1) == 'backup'])->order(60);
            }

            //Modules menu
            if (auth()->user()->can('manage_modules')) {
                $menu->url(action([\App\Http\Controllers\Install\ModulesController::class, 'index']), __('lang_v1.modules'), ['icon' => 'fa fas fa-plug', 'active' => request()->segment(1) == 'manage-modules'])->order(60);
            }

            //Booking menu
            if (in_array('booking', $enabled_modules) && (auth()->user()->can('crud_all_bookings') || auth()->user()->can('crud_own_bookings'))) {
                $menu->url(action([\App\Http\Controllers\Restaurant\BookingController::class, 'index']), __('restaurant.bookings'), ['icon' => 'fas fa fa-calendar-check', 'active' => request()->segment(1) == 'bookings'])->order(65);
            }

            //Kitchen menu
            if (in_array('kitchen', $enabled_modules)) {
                $menu->url(action([\App\Http\Controllers\Restaurant\KitchenController::class, 'index']), __('restaurant.kitchen'), ['icon' => 'fa fas fa-fire', 'active' => request()->segment(1) == 'modules' && request()->segment(2) == 'kitchen'])->order(70);
            }

            //Service Staff menu
            if (in_array('service_staff', $enabled_modules)) {
                $menu->url(action([\App\Http\Controllers\Restaurant\OrderController::class, 'index']), __('restaurant.orders'), ['icon' => 'fa fas fa-list-alt', 'active' => request()->segment(1) == 'modules' && request()->segment(2) == 'orders'])->order(75);
            }

            //Notification template menu
            if (auth()->user()->can('send_notifications')) {
                $menu->url(action([\App\Http\Controllers\NotificationTemplateController::class, 'index']), __('lang_v1.notification_templates'), ['icon' => 'fa fas fa-envelope', 'active' => request()->segment(1) == 'notification-templates'])->order(80);
            }

            //Settings Dropdown
            if (
                auth()->user()->can('business_settings.access') ||
                auth()->user()->can('barcode_settings.access') ||
                auth()->user()->can('invoice_settings.access') ||
                auth()->user()->can('tax_rate.view') ||
                auth()->user()->can('tax_rate.create') ||
                auth()->user()->can('access_package_subscriptions')
            ) {
                $menu->dropdown(
                    __('business.settings'),
                    function ($sub) use ($enabled_modules) {
                        if (auth()->user()->can('business_settings.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\BusinessController::class, 'getBusinessSettings']),
                                __('business.business_settings'),
                                ['icon' => 'fa fas fa-cogs', 'active' => request()->segment(1) == 'business', 'id' => 'tour_step2']
                            );
                            $sub->url(
                                action([\App\Http\Controllers\BusinessLocationController::class, 'index']),
                                __('business.business_locations'),
                                ['icon' => 'fa fas fa-map-marker', 'active' => request()->segment(1) == 'business-location']
                            );
                        }
                        if (auth()->user()->can('invoice_settings.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\InvoiceSchemeController::class, 'index']),
                                __('invoice.invoice_settings'),
                                ['icon' => 'fa fas fa-file', 'active' => in_array(request()->segment(1), ['invoice-schemes', 'invoice-layouts'])]
                            );
                        }
                        if (auth()->user()->can('barcode_settings.access')) {
                            $sub->url(
                                action([\App\Http\Controllers\BarcodeController::class, 'index']),
                                __('barcode.barcode_settings'),
                                ['icon' => 'fa fas fa-barcode', 'active' => request()->segment(1) == 'barcodes']
                            );
                        }
                        if (auth()->user()->can('access_printers')) {
                            $sub->url(
                                action([\App\Http\Controllers\PrinterController::class, 'index']),
                                __('printer.receipt_printers'),
                                ['icon' => 'fa fas fa-share-alt', 'active' => request()->segment(1) == 'printers']
                            );
                        }

                        if (auth()->user()->can('tax_rate.view') || auth()->user()->can('tax_rate.create')) {
                            $sub->url(
                                action([\App\Http\Controllers\TaxRateController::class, 'index']),
                                __('tax_rate.tax_rates'),
                                ['icon' => 'fa fas fa-bolt', 'active' => request()->segment(1) == 'tax-rates']
                            );
                        }

                        // if (auth()->user()->can('tax_rate.view') || auth()->user()->can('tax_rate.create')) {
                        $sub->url(
                            action([\App\Http\Controllers\HomeController::class, 'all_trans']),
                            __('home.all_trans'),
                            ['icon' => 'fa fas fa-bolt', 'active' => request()->segment(1) == 'all_trans']
                        );
                        // }
    
                        if (in_array('tables', $enabled_modules) && auth()->user()->can('access_tables')) {
                            $sub->url(
                                action([\App\Http\Controllers\Restaurant\TableController::class, 'index']),
                                __('restaurant.tables'),
                                ['icon' => 'fa fas fa-table', 'active' => request()->segment(1) == 'modules' && request()->segment(2) == 'tables']
                            );
                        }

                        if (in_array('modifiers', $enabled_modules) && (auth()->user()->can('product.view') || auth()->user()->can('product.create'))) {
                            $sub->url(
                                action([\App\Http\Controllers\Restaurant\ModifierSetsController::class, 'index']),
                                __('restaurant.modifiers'),
                                ['icon' => 'fa fas fa-pizza-slice', 'active' => request()->segment(1) == 'modules' && request()->segment(2) == 'modifiers']
                            );
                        }

                        if (in_array('types_of_service', $enabled_modules) && auth()->user()->can('access_types_of_service')) {
                            $sub->url(
                                action([\App\Http\Controllers\TypesOfServiceController::class, 'index']),
                                __('lang_v1.types_of_service'),
                                ['icon' => 'fa fas fa-user-circle', 'active' => request()->segment(1) == 'types-of-service']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-cog', 'id' => 'tour_step3']
                )->order(85);
            }


            // CRM

            // dd($enabled_modules);
            if (
                in_array('crm_module', $enabled_modules)
                &&
                (auth()->user()->can('crm.access_all_leads') ||
                    auth()->user()->can('crm.access_all_schedule') ||
                    auth()->user()->can('crm.access_all_campaigns') ||
                    auth()->user()->can('crm.access_contact_login') ||
                    (auth()->user()->can('crm.view_all_call_log') && config('constants.enable_crm_call_log')) ||
                    auth()->user()->can('crm.view_reports') ||
                    auth()->user()->can('crm.access_b2b_marketplace') ||
                    auth()->user()->can('crm.access_sources') ||
                    auth()->user()->can('crm.access_life_stage')
                )
            ) {
                $menu->dropdown(
                    __('CRM'),
                    function ($sub) {

                        if (auth()->user()->can('crm.access_all_leads') || auth()->user()->can('crm.access_own_leads')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\LeadController::class, 'index']) . '?lead_view=list_view',
                                __('crm::lang.leads'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'leads']
                            );
                        }
                        if (auth()->user()->can('crm.access_all_schedule') || auth()->user()->can('crm.access_own_schedule')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\ScheduleController::class, 'index']),
                                __('crm::lang.follow_ups'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'leads']
                            );
                        }
                        if (auth()->user()->can('crm.access_all_campaigns') || auth()->user()->can('crm.access_own_campaigns')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\CampaignController::class, 'index']),
                                __('crm::lang.campaigns'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'campaigns']
                            );
                        }
                        if (auth()->user()->can('crm.access_contact_login')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\ContactLoginController::class, 'allContactsLoginList']),
                                __('crm::lang.contacts_login'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'all-contacts-login']
                            );
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\ContactLoginController::class, 'commissions']),
                                __('crm::lang.commissions'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'commissions']
                            );
                        }
                        if ((auth()->user()->can('crm.view_all_call_log') || auth()->user()->can('crm.view_own_call_log')) && config('constants.enable_crm_call_log')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\CallLogController::class, 'index']),
                                __('crm::lang.contacts_login'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'call-log']
                            );
                        }
                        if (auth()->user()->can('crm.view_reports')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\ReportController::class, 'index']),
                                __('report.reports'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'reports']
                            );
                        }

                        $sub->url(
                            action([\Modules\Crm\Http\Controllers\ProposalTemplateController::class, 'index']),
                            __('crm::lang.proposal_template'),
                            ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'proposal-template']
                        );
                        $sub->url(
                            action([\Modules\Crm\Http\Controllers\ProposalController::class, 'index']),
                            __('crm::lang.proposals'),
                            ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'proposals']
                        );

                        if (auth()->user()->can('crm.access_b2b_marketplace') && config('constants.enable_b2b_marketplace')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\CrmMarketplaceController::class, 'index']),
                                __('crm::lang.b2b_marketplace'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'b2b-marketplace']
                            );
                        }
                        if (auth()->user()->can('crm.access_sources')) {
                            $sub->url(
                                action([\App\Http\Controllers\TaxonomyController::class, 'index']) . '?type=source',
                                __('crm::lang.sources'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'source']
                            );
                        }
                        if (auth()->user()->can('crm.access_life_stage')) {
                            $sub->url(
                                action([\App\Http\Controllers\TaxonomyController::class, 'index']) . '?type=life_stage',
                                __('crm::lang.life_stage'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'life_stage']
                            );
                            $sub->url(
                                action([\App\Http\Controllers\TaxonomyController::class, 'index']) . '?type=followup_category',
                                __('crm::lang.followup_category'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'followup_category']
                            );
                        }
                        if (auth()->user()->can('only_admin')) {
                            $sub->url(
                                action([\Modules\Crm\Http\Controllers\CrmSettingsController::class, 'index']),
                                __('business.settings'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'crm' && request()->segment(2) == 'settings']
                            );
                        }
                    },
                    ['icon' => 'fas fa-broadcast-tower']
                )->order(86);
            }

            // Project
            if (in_array('project_module', $enabled_modules) && (auth()->user()->can('project.create_project') || auth()->user()->can('project.edit_project') || auth()->user()->can('project.delete_project'))) {
                $menu->dropdown(
                    __('Project'),
                    function ($sub) {
                        if (auth()->user()->can('project.create_project')) {
                            $sub->url(
                                url('/project/project?project_view=list_view'),
                                __('projects'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'project' && request()->get('project_view') == 'list_view']
                            );
                            $sub->url(
                                url('/project/project-task'),
                                __('My Tasks'),
                                ['icon' => 'fas fa-industry', 'active' => request()->segment(2) == 'project-task']
                            );
                        }
                        if (auth()->user()->can('only_admin')) {
                            $sub->url(
                                url('/project/project-reports'),
                                __('Reports'),
                                [
                                    'icon' => 'fas fa-cog',
                                    'active' => Request::is('project/project-reports')
                                ]
                            );
                            $sub->url(
                                url('/taxonomies?type=project'),
                                __('Project Categories'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'taxonomies' && request()->get('type') == 'project']
                            );
                        }
                    },
                    ['icon' => 'fa fa-project-diagram']
                )->order(86);
            }
            // Asset Management
            if (in_array('assetmanagement_module', $enabled_modules) && (auth()->user()->can('asset.view') || auth()->user()->can('asset.view_all_maintenance') || auth()->user()->can('asset.view_own_maintenance'))) {
                $menu->dropdown(
                    __('Asset Management'),
                    function ($sub) {

                        if (auth()->user()->can('asset.view')) {
                            $sub->url(
                                action([\Modules\AssetManagement\Http\Controllers\AssetController::class, 'index']),
                                __('assetmanagement::lang.assets'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'dashboard']
                            );
                            $sub->url(
                                action([\Modules\AssetManagement\Http\Controllers\AssetAllocationController::class, 'index']),
                                __('assetmanagement::lang.asset_allocated'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'allocation']
                            );
                            $sub->url(
                                action([\Modules\AssetManagement\Http\Controllers\RevokeAllocatedAssetController::class, 'index']),
                                __('assetmanagement::lang.revoked_asset'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'revocation']
                            );
                        }

                        if (auth()->user()->can('asset.view_all_maintenance') || auth()->user()->can('asset.view_own_maintenance')) {
                            $sub->url(
                                action([\Modules\AssetManagement\Http\Controllers\AssetMaitenanceController::class, 'index']),
                                __('assetmanagement::lang.asset_maintenance'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'maintenance']
                            );
                        }
                        if (auth()->user()->can('only_admin')) {
                            $sub->url(
                                action([\App\Http\Controllers\TaxonomyController::class, 'index']) . '?type=asset',
                                __('assetmanagement::lang.asset_categories'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'asset']
                            );
                            $sub->url(
                                action([\Modules\AssetManagement\Http\Controllers\AssetSettingsController::class, 'index']),
                                __('role.settings'),
                                ['icon' => 'fa fas fa-list', 'active' => request()->segment(1) == 'asset' && request()->segment(2) == 'settings']
                            );
                        }
                    },
                    ['icon' => 'fas fa fa-boxes']
                )->order(86);
            }

            // HRM Management
            if (
                in_array('essentials_module', $enabled_modules) &&
                (auth()->user()->can('edit_essentials_settings') ||
                    auth()->user()->can('essentials.crud_all_leave') ||
                    auth()->user()->can('essentials.crud_own_leave') ||
                    auth()->user()->can('essentials.crud_all_attendance') ||
                    auth()->user()->can('essentials.view_own_attendance') ||
                    auth()->user()->can('essentials.crud_department') ||
                    auth()->user()->can('essentials.crud_designation') ||
                    auth()->user()->can('essentials.access_sales_target') ||
                    auth()->user()->can('edit_essentials_settings'))
            ) {
                $menu->dropdown(
                    __('HRM'),
                    function ($sub) {
                        $sub->url(
                            url('/hrm/dashboard'),
                            __('Dashboard'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'hrm' && request()->segment(2) == 'dashboard']
                        );
                        if (auth()->user()->can('essentials.crud_leave_type')) {

                            $sub->url(
                                url('/hrm/leave-type'),
                                __('Leave Type'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'hrm' && request()->segment(2) == 'leave-type']
                            );
                        }
                        if (
                            auth()->user()->can('essentials.crud_all_leave') ||
                            auth()->user()->can('essentials.crud_own_leave')
                        ) {

                            $sub->url(
                                url('/hrm/leave'),
                                __('Leave'),
                                [
                                    'icon' => 'fas fa-cog',
                                    'active' => request()->segment(1) == 'hrm' && request()->segment(2) == 'leave'
                                ]
                            );
                        }
                        if (
                            auth()->user()->can('essentials.crud_all_attendance') ||
                            auth()->user()->can('essentials.view_own_attendance')
                        ) {

                            $sub->url(
                                url('/hrm/attendance'),
                                __('Attendance'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(2) == 'attendance']
                            );
                        }
                        $sub->url(
                            url('/hrm/payroll'),
                            __('Payroll'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'hrm' && request()->segment(2) == 'payroll']
                        );
                        $sub->url(
                            url('/hrm/holiday'),
                            __('Holiday'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'hrm' && request()->segment(2) == 'holiday']
                        );
                        if (
                            auth()->user()->can('essentials.crud_department')
                        ) {

                            $sub->url(
                                url('/taxonomies?type=hrm_department'),
                                __('Department'),
                                ['icon' => 'fas fa-chart-pie', 'active' => Request::is('taxonomies?type=hrm_department')]
                            );
                        }
                        if (
                            auth()->user()->can('essentials.crud_designation')
                        ) {

                            $sub->url(
                                url('/taxonomies?type=hrm_designation'),
                                __('Designations'),
                                ['icon' => 'fas fa-chart-pie', 'active' => Request::is('taxonomies?type=hrm_designation')]
                            );
                        }
                        if (
                            auth()->user()->can('essentials.access_sales_target')
                        ) {
                            $sub->url(
                                url('/hrm/sales-target'),
                                __('Sales Targets'),
                                ['icon' => 'fas fa-chart-pie', 'active' => Request::is('hrm/sales-target')]
                            );
                        }
                        if (
                            auth()->user()->can('edit_essentials_settings')
                        ) {
                            $sub->url(
                                url('/hrm/settings'),
                                __('Settings'),
                                ['icon' => 'fas fa-chart-pie', 'active' => Request::is('hrm/settings')]
                            );
                            $sub->url(
                                url('/hrm/calcualte'),
                                __('Calculate'),
                                ['icon' => 'fas fa-chart-pie', 'active' => Request::is('hrm/calcualte')]
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-users']
                )->order(86);
            }

            // Essentials
            if (
                in_array('essentials_module', $enabled_modules) &&
                (auth()->user()->can('essentials.edit_todos') ||
                    auth()->user()->can('essentials.delete_todos') ||
                    auth()->user()->can('essentials.access_sales_target') ||
                    auth()->user()->can('essentials.crud_own_leave') ||
                    auth()->user()->can('essentials.view_own_attendance') ||
                    auth()->user()->can('essentials.create_message') ||
                    auth()->user()->can('essentials.view_message') ||
                    auth()->user()->can('essentials.assign_todos'))
            ) {
                $menu->dropdown(
                    __('Essentials'),
                    function ($sub) {
                        if (auth()->user()->can('assign_todos')) {
                            $sub->url(
                                url('/essentials/todo'),
                                __('To Do'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'essentials' && request()->segment(2) == 'todo']
                            );
                        }
                        $sub->url(
                            url('/essentials/document'),
                            __('Document'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'essentials' && request()->segment(2) == 'document']
                        );
                        $sub->url(
                            url('/essentials/document?type=memos'),
                            __('Memos'),
                            [
                                'icon' => 'fas fa-cog',
                                'active' => Request::is('essentials/document?type=memos')
                            ]
                        );
                        if (auth()->user()->can('essentials.view_message') || auth()->user()->can('essentials.create_message')) {
                            $sub->url(
                                url('/essentials/reminder'),
                                __('Reminders'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'essentials' && request()->segment(2) == 'reminder']
                            );
                        }
                        $sub->url(
                            url('/essentials/messages'),
                            __(' Messages'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'essentials' && request()->segment(2) == 'messages']
                        );
                        if (auth()->user()->can('edit_essentials_settings')) {
                            $sub->url(
                                url('/essentials/knowledge-base'),
                                __('knowledge Base'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'essentials' && request()->segment(2) == 'knowledge-base']
                            );
                        }
                    },
                    ['icon' => 'fa fas fa-check-circle']
                )->order(86);
            }
            // Woocommerce
            if (in_array('woocommerce_module', $enabled_modules) && (auth()->user()->can('woocommerce.sync_orders') || auth()->user()->can('woocommerce.access_woocommerce_api_settings'))) {
                $menu->dropdown(
                    __('Woocommerce'),
                    function ($sub) {
                        $sub->url(
                            url('/woocommerce'),
                            __('Woocommerce'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'woocommerce']
                        );
                        if (auth()->user()->can('woocommerce.sync_orders')) {
                            $sub->url(
                                url('/woocommerce/view-sync-log'),
                                __('Sync Log'),
                                ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'woocommerce' && request()->segment(2) == 'view-sync-log']
                            );
                        }
                        if (auth()->user()->can('woocommerce.access_woocommerce_api_settings')) {
                            $sub->url(
                                url('/woocommerce/api-settings'),
                                __('Api Settings'),
                                [
                                    'icon' => 'fas fa-cog',
                                    'active' => Request::is('woocommerce/api-settings')
                                ]
                            );
                        }
                    },
                    ['icon' => 'fab fa-wordpress']
                )->order(86);
            }
            // Connector
            if (in_array('connector_module', $enabled_modules) && auth()->user()->can('only_admin')) {
                $menu->dropdown(
                    __('Connector'),
                    function ($sub) {
                        $sub->url(
                            url('/connector/client'),
                            __('clients'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'client']
                        );
                    },
                    ['icon' => 'fas fa-plug']
                )->order(86);
            }
            // Spreadsheet
            if (in_array('spreadsheet_module', $enabled_modules) && (auth()->user()->can('access.spreadsheet') || auth()->user()->can('create.spreadsheet'))) {
                $menu->dropdown(
                    __('Spreadsheet'),
                    function ($sub) {
                        $sub->url(
                            url('/spreadsheet/sheets'),
                            __('Spreadsheet'),
                            ['icon' => 'fas fa-chart-pie', 'active' => request()->segment(1) == 'sheets']
                        );
                    },
                    ['icon' => 'fas fa fa-file-excel']
                )->order(86);
            }
        });


        //Add menus from modules
        //Add menus from modules
        // $moduleUtil = new ModuleUtil;
        // $moduleUtil->getModuleData('modifyAdminMenu');
        return $next($request);
    }
}