<?php

 return [
     'printers' => 'الطابعات',
     'add_printer' => 'أضف طابعة',
     'name' => 'اسم الطابعة',
     'connection_type' => 'نوع الاتصال',
     'capability_profile' => 'القدرة',
     'ip_address' => 'عنوان IP',
     'port' => 'المنفذ',
     'path' => 'المسار',
     'added_success' => 'تمت إضافة الطابعة بنجاح',
     'manage_your_printers' => 'إدارة الطابعات الخاصة بك',
     'all_your_printer' => 'جميع الطابعات التي تم تكوينها',
     'deleted_success' => 'تم حذف الطابعة بنجاح',
     'edit_printer_setting' => 'قم بتعديل اعدادات الطابعة',
     'receipt_printers' => 'طابعات الايصالات',
     'character_per_line' => 'الأحرف في كل سطر',
     'printer_name' => 'اسم الطابعة',
     'updated_success' => 'تم تحديث الطابعة بنجاح',
     'edit_printer' => 'تعديل الطابعة',
 ];
