(function() {
    'use strict';

    var termsScroll = document.getElementById('terms-scroll');
    new SimpleBar(termsScroll, { autoHide: true });
     
})()